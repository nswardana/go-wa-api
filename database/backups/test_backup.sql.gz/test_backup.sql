--
-- PostgreSQL database dump
--

\restrict L8xP09bmjsWwScrSdlGsdH1esHd7SgE8Z9ha06VOlSif9tavkoN26tbjQb9qIYb

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: chatflow_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO chatflow_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_usage; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.api_usage (
    id integer NOT NULL,
    user_id integer,
    phone_number_id integer,
    endpoint character varying(100) NOT NULL,
    method character varying(10) NOT NULL,
    status_code integer NOT NULL,
    response_time integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_usage OWNER TO chatflow_user;

--
-- Name: api_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.api_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_usage_id_seq OWNER TO chatflow_user;

--
-- Name: api_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.api_usage_id_seq OWNED BY public.api_usage.id;


--
-- Name: auto_reply_configs; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_configs (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    trigger_keywords text[] NOT NULL,
    welcome_message text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    phone_numbers integer[] DEFAULT '{}'::integer[]
);


ALTER TABLE public.auto_reply_configs OWNER TO chatflow_user;

--
-- Name: auto_reply_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_configs_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_configs_id_seq OWNED BY public.auto_reply_configs.id;


--
-- Name: auto_reply_logs; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_logs (
    id integer NOT NULL,
    phone_number character varying(20) NOT NULL,
    incoming_message text NOT NULL,
    outgoing_message text NOT NULL,
    menu_path character varying(100),
    response_time integer,
    session_id integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auto_reply_logs OWNER TO chatflow_user;

--
-- Name: auto_reply_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_logs_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_logs_id_seq OWNED BY public.auto_reply_logs.id;


--
-- Name: auto_reply_menus; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_menus (
    id integer NOT NULL,
    config_id integer,
    menu_key character varying(10) NOT NULL,
    menu_text text NOT NULL,
    response_text text NOT NULL,
    parent_menu_id integer,
    is_active boolean DEFAULT true,
    order_index integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auto_reply_menus OWNER TO chatflow_user;

--
-- Name: auto_reply_menus_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_menus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_menus_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_menus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_menus_id_seq OWNED BY public.auto_reply_menus.id;


--
-- Name: auto_reply_sessions; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_sessions (
    id integer NOT NULL,
    phone_number character varying(20) NOT NULL,
    config_id integer,
    current_menu_id integer,
    session_data jsonb DEFAULT '{}'::jsonb,
    last_interaction timestamp without time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    phone_number_id integer
);


ALTER TABLE public.auto_reply_sessions OWNER TO chatflow_user;

--
-- Name: auto_reply_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_sessions_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_sessions_id_seq OWNED BY public.auto_reply_sessions.id;


--
-- Name: broadcast_messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_messages (
    id integer NOT NULL,
    broadcast_id integer,
    contact_id integer,
    phone character varying(20) NOT NULL,
    message text NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    sent_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_messages OWNER TO chatflow_user;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_messages_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_messages_id_seq OWNED BY public.broadcast_messages.id;


--
-- Name: broadcast_progress; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_progress (
    id integer NOT NULL,
    broadcast_id integer,
    total_contacts integer DEFAULT 0,
    processed_contacts integer DEFAULT 0,
    sent_messages integer DEFAULT 0,
    failed_messages integer DEFAULT 0,
    progress_percentage numeric(5,2) DEFAULT 0,
    estimated_completion timestamp without time zone,
    last_updated timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_progress OWNER TO chatflow_user;

--
-- Name: broadcast_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_progress_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_progress_id_seq OWNED BY public.broadcast_progress.id;


--
-- Name: broadcast_recipients; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_recipients (
    id integer NOT NULL,
    broadcast_id integer,
    contact_id integer,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp without time zone,
    failed_at timestamp without time zone,
    message_id text,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_recipients OWNER TO chatflow_user;

--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_recipients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_recipients_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_recipients_id_seq OWNED BY public.broadcast_recipients.id;


--
-- Name: broadcast_templates; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_templates (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    description text,
    message text NOT NULL,
    variables jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_templates OWNER TO chatflow_user;

--
-- Name: broadcast_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_templates_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_templates_id_seq OWNED BY public.broadcast_templates.id;


--
-- Name: broadcasts; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcasts (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    description text,
    message text NOT NULL,
    template_id integer,
    contact_filter jsonb,
    status character varying(50) DEFAULT 'draft'::character varying,
    total_contacts integer DEFAULT 0,
    sent_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    scheduled_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcasts OWNER TO chatflow_user;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcasts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcasts_id_seq OWNER TO chatflow_user;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcasts_id_seq OWNED BY public.broadcasts.id;


--
-- Name: contact_categories; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.contact_categories (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#1976d2'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.contact_categories OWNER TO chatflow_user;

--
-- Name: contact_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.contact_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_categories_id_seq OWNER TO chatflow_user;

--
-- Name: contact_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.contact_categories_id_seq OWNED BY public.contact_categories.id;


--
-- Name: contact_category_relations; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.contact_category_relations (
    id integer NOT NULL,
    contact_id integer,
    category_id integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.contact_category_relations OWNER TO chatflow_user;

--
-- Name: contact_category_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.contact_category_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_category_relations_id_seq OWNER TO chatflow_user;

--
-- Name: contact_category_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.contact_category_relations_id_seq OWNED BY public.contact_category_relations.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    company character varying(255),
    address text,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    categories text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.contacts OWNER TO chatflow_user;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO chatflow_user;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.message_templates (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    content text NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying,
    variables jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.message_templates OWNER TO chatflow_user;

--
-- Name: message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.message_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_templates_id_seq OWNER TO chatflow_user;

--
-- Name: message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.message_templates_id_seq OWNED BY public.message_templates.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    phone_number_id integer,
    message_id character varying(100) NOT NULL,
    from_number character varying(20) NOT NULL,
    to_number character varying(20) NOT NULL,
    message_type character varying(20) NOT NULL,
    content text,
    media_url character varying(500),
    media_type character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    webhook_sent boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.messages OWNER TO chatflow_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO chatflow_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: phone_numbers; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.phone_numbers (
    id integer NOT NULL,
    user_id integer,
    phone_number character varying(20) NOT NULL,
    device_name character varying(100),
    token character varying(255) NOT NULL,
    webhook_url character varying(500),
    webhook_secret character varying(255),
    is_connected boolean DEFAULT false,
    last_seen timestamp with time zone,
    qr_code text,
    session_data jsonb,
    auto_reply text,
    auto_mark_read boolean DEFAULT false,
    auto_download_media boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    evolution_instance character varying(255)
);


ALTER TABLE public.phone_numbers OWNER TO chatflow_user;

--
-- Name: phone_numbers_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.phone_numbers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phone_numbers_id_seq OWNER TO chatflow_user;

--
-- Name: phone_numbers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.phone_numbers_id_seq OWNED BY public.phone_numbers.id;


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    user_id integer,
    window_start timestamp with time zone NOT NULL,
    request_count integer DEFAULT 0,
    limit_per_hour integer DEFAULT 1000,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rate_limits OWNER TO chatflow_user;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rate_limits_id_seq OWNER TO chatflow_user;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: scheduled_messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.scheduled_messages (
    id integer NOT NULL,
    user_id integer,
    phone_id integer,
    recipient character varying(50) NOT NULL,
    message text NOT NULL,
    scheduled_at timestamp without time zone NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.scheduled_messages OWNER TO chatflow_user;

--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.scheduled_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduled_messages_id_seq OWNER TO chatflow_user;

--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.scheduled_messages_id_seq OWNED BY public.scheduled_messages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    api_key character varying(255) NOT NULL,
    jwt_secret character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO chatflow_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO chatflow_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.webhook_events (
    id integer NOT NULL,
    phone_number_id integer,
    event_type character varying(50) NOT NULL,
    payload jsonb NOT NULL,
    retry_count integer DEFAULT 0,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhook_events OWNER TO chatflow_user;

--
-- Name: webhook_events_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.webhook_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webhook_events_id_seq OWNER TO chatflow_user;

--
-- Name: webhook_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.webhook_events_id_seq OWNED BY public.webhook_events.id;


--
-- Name: api_usage id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage ALTER COLUMN id SET DEFAULT nextval('public.api_usage_id_seq'::regclass);


--
-- Name: auto_reply_configs id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_configs ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_configs_id_seq'::regclass);


--
-- Name: auto_reply_logs id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_logs ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_logs_id_seq'::regclass);


--
-- Name: auto_reply_menus id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_menus_id_seq'::regclass);


--
-- Name: auto_reply_sessions id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_sessions_id_seq'::regclass);


--
-- Name: broadcast_messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages ALTER COLUMN id SET DEFAULT nextval('public.broadcast_messages_id_seq'::regclass);


--
-- Name: broadcast_progress id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_progress ALTER COLUMN id SET DEFAULT nextval('public.broadcast_progress_id_seq'::regclass);


--
-- Name: broadcast_recipients id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients ALTER COLUMN id SET DEFAULT nextval('public.broadcast_recipients_id_seq'::regclass);


--
-- Name: broadcast_templates id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_templates ALTER COLUMN id SET DEFAULT nextval('public.broadcast_templates_id_seq'::regclass);


--
-- Name: broadcasts id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts ALTER COLUMN id SET DEFAULT nextval('public.broadcasts_id_seq'::regclass);


--
-- Name: contact_categories id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories ALTER COLUMN id SET DEFAULT nextval('public.contact_categories_id_seq'::regclass);


--
-- Name: contact_category_relations id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations ALTER COLUMN id SET DEFAULT nextval('public.contact_category_relations_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: message_templates id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.message_templates ALTER COLUMN id SET DEFAULT nextval('public.message_templates_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: phone_numbers id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers ALTER COLUMN id SET DEFAULT nextval('public.phone_numbers_id_seq'::regclass);


--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: scheduled_messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.scheduled_messages ALTER COLUMN id SET DEFAULT nextval('public.scheduled_messages_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: webhook_events id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.webhook_events ALTER COLUMN id SET DEFAULT nextval('public.webhook_events_id_seq'::regclass);


--
-- Data for Name: api_usage; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.api_usage (id, user_id, phone_number_id, endpoint, method, status_code, response_time, created_at) FROM stdin;
\.


--
-- Data for Name: auto_reply_configs; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_configs (id, user_id, name, trigger_keywords, welcome_message, is_active, created_at, updated_at, phone_numbers) FROM stdin;
1	1	HR Helpdesk	{halo,help,bantuan,info}	Halo, ada yang bisa saya bantu?\n====================\nInfo lainnya, silakan KETIK angka:\n1.👉🏻 Data Karyawan\n2.👉🏻 Data dan Form Cuti\n3.👉🏻 Data dan Form Lembur\n4.👉🏻 Password Akun\n5.👉🏻 Lowongan Kerja\n====================	t	2026-02-10 12:35:33.715917	2026-02-10 12:35:33.715917	{}
2	1	HR Helpdesk - Specific Phone	{halo,help,bantuan,info}	Ass.wr.wb, ada yang bisa saya bantu? (Test Auto Reply)	t	2026-02-10 12:57:32.329541	2026-02-10 13:05:23.793418	{6}
\.


--
-- Data for Name: auto_reply_logs; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_logs (id, phone_number, incoming_message, outgoing_message, menu_path, response_time, session_id, created_at) FROM stdin;
1	+62812345678	halo	Halo, ada yang bisa saya bantu?\n====================\nInfo lainnya, silakan KETIK angka:\n1.👉🏻 Data Karyawan\n2.👉🏻 Data dan Form Cuti\n3.👉🏻 Data dan Form Lembur\n4.👉🏻 Password Akun\n5.👉🏻 Lowongan Kerja\n====================	welcome	19	1	2026-02-10 23:10:00.160973
\.


--
-- Data for Name: auto_reply_menus; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_menus (id, config_id, menu_key, menu_text, response_text, parent_menu_id, is_active, order_index, created_at) FROM stdin;
1	1	1	👉🏻 Data Karyawan	Untuk data karyawan, silakan akses: https://hr.company.com/employees\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.722994
2	1	2	👉🏻 Data dan Form Cuti	Form cuti tersedia di: https://hr.company.com/cuti\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.72752
3	1	3	👉🏻 Data dan Form Lembur	Form lembur tersedia di: https://hr.company.com/lembur\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.730824
4	1	4	👉🏻 Password Akun	Untuk reset password, hubungi IT Helpdesk di ext. 1234\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.733146
5	1	5	👉🏻 Lowongan Kerja	Lowongan tersedia di: https://careers.company.com\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.735416
\.


--
-- Data for Name: auto_reply_sessions; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_sessions (id, phone_number, config_id, current_menu_id, session_data, last_interaction, is_active, created_at, phone_number_id) FROM stdin;
1	+62812345678	1	\N	{}	2026-02-10 23:10:00.15403	t	2026-02-10 23:10:00.15403	7
\.


--
-- Data for Name: broadcast_messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_messages (id, broadcast_id, contact_id, phone, message, status, sent_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: broadcast_progress; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_progress (id, broadcast_id, total_contacts, processed_contacts, sent_messages, failed_messages, progress_percentage, estimated_completion, last_updated) FROM stdin;
\.


--
-- Data for Name: broadcast_recipients; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_recipients (id, broadcast_id, contact_id, status, sent_at, failed_at, message_id, error_message, created_at, updated_at) FROM stdin;
8	14	24	failed	\N	2026-02-10 04:08:23.349278	\N	Request failed with status code 404	2026-02-10 04:08:23.349278	2026-02-10 04:08:23.349278
9	15	24	failed	\N	2026-02-10 04:13:08.575181	\N	Request failed with status code 404	2026-02-10 04:13:08.575181	2026-02-10 04:13:08.575181
10	16	24	failed	\N	2026-02-10 04:18:06.524519	\N	Request failed with status code 404	2026-02-10 04:18:06.524519	2026-02-10 04:18:06.524519
11	17	24	failed	\N	2026-02-10 04:21:17.150216	\N	Request failed with status code 404	2026-02-10 04:21:17.150216	2026-02-10 04:21:17.150216
12	18	24	failed	\N	2026-02-10 07:11:45.841607	\N	Request failed with status code 404	2026-02-10 07:11:45.841607	2026-02-10 07:11:45.841607
13	19	24	sent	2026-02-10 08:01:51.671354	\N	\N	\N	2026-02-10 08:01:51.671354	2026-02-10 08:01:51.671354
14	20	24	sent	2026-02-10 08:09:54.658266	\N	\N	\N	2026-02-10 08:09:54.658266	2026-02-10 08:09:54.658266
15	21	24	sent	2026-02-10 08:14:14.484018	\N	\N	\N	2026-02-10 08:14:14.484018	2026-02-10 08:14:14.484018
16	22	24	sent	2026-02-10 08:16:37.886373	\N	\N	\N	2026-02-10 08:16:37.886373	2026-02-10 08:16:37.886373
17	23	24	sent	2026-02-10 09:55:59.468144	\N	\N	\N	2026-02-10 09:55:59.468144	2026-02-10 09:55:59.468144
18	28	24	sent	2026-02-10 10:30:43.100803	\N	\N	\N	2026-02-10 10:30:43.100803	2026-02-10 10:30:43.100803
19	28	27	sent	2026-02-10 10:30:45.862852	\N	\N	\N	2026-02-10 10:30:45.862852	2026-02-10 10:30:45.862852
20	27	24	sent	2026-02-10 10:37:55.646897	\N	\N	\N	2026-02-10 10:37:55.646897	2026-02-10 10:37:55.646897
21	27	27	sent	2026-02-10 10:37:58.144171	\N	\N	\N	2026-02-10 10:37:58.144171	2026-02-10 10:37:58.144171
22	25	24	sent	2026-02-10 10:38:28.905738	\N	\N	\N	2026-02-10 10:38:28.905738	2026-02-10 10:38:28.905738
23	25	27	sent	2026-02-10 10:38:31.432278	\N	\N	\N	2026-02-10 10:38:31.432278	2026-02-10 10:38:31.432278
24	29	24	sent	2026-02-10 10:41:11.106892	\N	\N	\N	2026-02-10 10:41:11.106892	2026-02-10 10:41:11.106892
25	29	27	sent	2026-02-10 10:41:13.698109	\N	\N	\N	2026-02-10 10:41:13.698109	2026-02-10 10:41:13.698109
26	30	24	sent	2026-02-10 11:03:21.733957	\N	\N	\N	2026-02-10 11:03:21.733957	2026-02-10 11:03:21.733957
27	30	27	sent	2026-02-10 11:03:24.231668	\N	\N	\N	2026-02-10 11:03:24.231668	2026-02-10 11:03:24.231668
28	31	24	sent	2026-02-10 11:28:47.741115	\N	\N	\N	2026-02-10 11:28:47.741115	2026-02-10 11:28:47.741115
29	31	27	sent	2026-02-10 11:28:49.680011	\N	\N	\N	2026-02-10 11:28:49.680011	2026-02-10 11:28:49.680011
30	32	24	sent	2026-02-10 14:28:52.391972	\N	\N	\N	2026-02-10 14:28:52.391972	2026-02-10 14:28:52.391972
31	32	27	sent	2026-02-10 14:28:54.310297	\N	\N	\N	2026-02-10 14:28:54.310297	2026-02-10 14:28:54.310297
\.


--
-- Data for Name: broadcast_templates; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_templates (id, user_id, name, description, message, variables, created_at, updated_at) FROM stdin;
1	1	Welcome Template	Welcome message template	Hello {name}, welcome to our service!	{"name": "text"}	2026-02-09 10:21:45.523134	2026-02-09 10:21:45.523134
\.


--
-- Data for Name: broadcasts; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcasts (id, user_id, name, description, message, template_id, contact_filter, status, total_contacts, sent_count, failed_count, scheduled_at, started_at, completed_at, created_at, updated_at) FROM stdin;
18	1	Test dengan Connected Device	Test broadcast dengan device yang sudah connected	Hello {name}, test dengan device yang sudah connected!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 07:11:45.820186	2026-02-10 07:11:45.846106	2026-02-10 07:11:39.473267	2026-02-10 07:11:45.829819
19	1	BIsmillah	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:01:48.628075	2026-02-10 08:01:51.678768	2026-02-10 08:01:45.734231	2026-02-10 08:01:48.643284
20	1	BISMILLAH	BIsmillah	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:09:52.230837	2026-02-10 08:09:54.665769	2026-02-10 08:09:48.602942	2026-02-10 08:09:52.239834
21	1	bismillah	cuba lagi	bismillah	\N	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:14:12.466392	2026-02-10 08:14:14.494048	2026-02-10 08:14:09.102251	2026-02-10 08:14:12.49572
22	1	Bismillah	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:16:35.795835	2026-02-10 08:16:37.894944	2026-02-10 08:16:16.006588	2026-02-10 08:16:35.81182
23	1	BIsmillah	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 09:55:56.008351	2026-02-10 09:55:59.471803	2026-02-10 09:55:51.849187	2026-02-10 09:55:56.053453
24	1	Template	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	draft	1	0	0	\N	\N	\N	2026-02-10 10:01:31.414595	2026-02-10 10:01:31.414595
28	1	desc	saw	asdasd	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:30:40.188161	2026-02-10 10:30:45.867796	2026-02-10 10:30:36.716403	2026-02-10 10:30:40.208675
27	1	Test Recipient Count Fix	Test dengan correct category data	Hello {name}, test dengan correct recipient count!	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:37:53.846067	2026-02-10 10:37:58.14838	2026-02-10 10:29:26.990658	2026-02-10 10:37:53.869383
25	1	template	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:38:26.830631	2026-02-10 10:38:31.436671	2026-02-10 10:09:34.959301	2026-02-10 10:38:26.891534
29	1	Bismillah	bismilla	check	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:41:08.913052	2026-02-10 10:41:13.701526	2026-02-10 10:41:06.0756	2026-02-10 10:41:08.924019
14	1	Real WhatsApp Test	Test dengan Evolution API langsung	Hello {name}, ini adalah test pesan langsung ke Evolution API!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:08:23.315113	2026-02-10 04:08:23.356902	2026-02-10 04:08:16.150257	2026-02-10 04:08:23.328271
30	1	Bismillah	ds	bismillah	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 11:03:18.962433	2026-02-10 11:03:24.234665	2026-02-10 11:03:16.366304	2026-02-10 11:03:18.988827
15	1	Real WhatsApp Test 2	Test dengan endpoint /send/message	Hello {name}, ini adalah test pesan dengan endpoint yang benar!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:13:08.562943	2026-02-10 04:13:08.57934	2026-02-10 04:12:58.496472	2026-02-10 04:13:08.568009
31	1	BIsmillah		BIsmillah	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 11:28:46.234476	2026-02-10 11:28:49.683058	2026-02-10 11:28:43.000571	2026-02-10 11:28:46.260936
16	1	bism	d	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:18:06.314291	2026-02-10 04:18:06.534346	2026-02-10 04:17:40.257963	2026-02-10 04:18:06.3447
17	1	Test dengan Device ID Mock	Test menggunakan hardcoded device ID	Hello {name}, test dengan device ID mock!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:21:17.114281	2026-02-10 04:21:17.154172	2026-02-10 04:21:07.045262	2026-02-10 04:21:17.132412
32	1	Bismillah	desc	BIsmillah	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 14:28:50.90284	2026-02-10 14:28:54.314243	2026-02-10 14:28:44.012592	2026-02-10 14:28:50.990759
\.


--
-- Data for Name: contact_categories; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.contact_categories (id, user_id, name, description, color, created_at, updated_at) FROM stdin;
1	1	Test Category	Test category for contacts	#ff5722	2026-02-09 09:21:25.515341	2026-02-09 09:21:25.515341
2	1	kawan2	desc	#d27219	2026-02-09 09:29:22.012276	2026-02-09 09:29:22.012276
5	1	New Test Category	New Test Description	#00FF00	2026-02-09 09:56:05.168126	2026-02-09 09:56:05.168126
\.


--
-- Data for Name: contact_category_relations; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.contact_category_relations (id, contact_id, category_id, created_at) FROM stdin;
9	24	2	2026-02-09 14:40:36.420637
14	27	1	2026-02-10 10:00:30.906045
15	27	2	2026-02-10 10:00:30.906045
16	28	2	2026-02-10 11:28:13.15237
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.contacts (id, user_id, name, phone, email, company, address, notes, created_at, updated_at, categories) FROM stdin;
24	1	zahirtamimi	+6281213775718	nswardana@gmail.com		Victoria sentul city		2026-02-09 10:15:16.008717	2026-02-09 14:40:36.420637	{kawan2}
27	1	NANANG SETYA WARDANA	+62818223304	nswardana@gmail.com	\N	49, JALAN TIMUR 6, BANDAR BARU ENSTEK, 71800 BANDAR BARU ENSTEK, NEGERI SEMBILAN,	\N	2026-02-10 10:00:30.906045	2026-02-10 10:27:40.893604	{"Test Category",kawan2}
28	1	Umu Laila	+6287874875768		\N	\N	\N	2026-02-10 11:28:13.15237	2026-02-10 11:28:13.15237	{}
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.message_templates (id, user_id, name, content, category, variables, is_active, created_at, updated_at) FROM stdin;
1	1	Welcome Message	Hello {{name}}! Welcome to our service. We are glad to have you with us!	welcome	["name"]	t	2026-02-08 15:23:22.44203	2026-02-08 15:23:22.44203
2	1	Order Confirmation	Dear {{name}}, your order #{{order_id}} has been confirmed. Total: {{amount}}.	notification	["name", "order_id", "amount"]	t	2026-02-08 15:23:22.44203	2026-02-08 15:23:22.44203
3	1	Flash Sale	🔥 FLASH SALE! Get {{discount}}% off on all items! Use code: {{promo_code}}.	promotion	["discount", "promo_code"]	t	2026-02-08 15:23:22.44203	2026-02-08 15:23:22.44203
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.messages (id, phone_number_id, message_id, from_number, to_number, message_type, content, media_url, media_type, status, webhook_sent, created_at, updated_at) FROM stdin;
2	6	msg_1770617746151	+62818223304	+6281213775718	image	test dari depan	\N	\N	sent	f	2026-02-09 06:15:46.151341+00	2026-02-09 06:15:46.151341+00
3	6	msg_1770617835789	+62818223304	+6281213775718	image	test dari depan	\N	\N	sent	f	2026-02-09 06:17:15.784273+00	2026-02-09 06:17:15.784273+00
4	6	msg_1770617840767	+62818223304	+6281213775718	image	test dari depan	\N	\N	sent	f	2026-02-09 06:17:20.762288+00	2026-02-09 06:17:20.762288+00
5	6	msg_1770617908885	+62818223304	+6281213775718	image	test dari depan	\N	\N	sent	f	2026-02-09 06:18:28.887144+00	2026-02-09 06:18:28.887144+00
6	6	msg_1770619586074	+62818223304	+6281213775718	image	cuba send message kok ga bisa2	\N	\N	sent	f	2026-02-09 06:46:26.07545+00	2026-02-09 06:46:26.07545+00
7	6	msg_1770619661684	+62818223304	+6281286431751	text	wah, masuk ga wa saya	\N	\N	sent	f	2026-02-09 06:47:41.68388+00	2026-02-09 06:47:41.68388+00
8	6	3EB00CA76E6D951DC9614E	+62818223304	+6281213775718	text	test from backend after connection fix	\N	\N	sent	f	2026-02-09 06:54:12.613499+00	2026-02-09 06:54:12.613499+00
9	6	3EB0860825E39D0E86B206	+62818223304	+6281286431751	text	test ya	\N	\N	sent	f	2026-02-09 06:57:36.723691+00	2026-02-09 06:57:36.723691+00
10	6	msg_received_1	+6281213775718	+62818223304	text	Test received message	\N	\N	received	f	2026-02-09 07:07:49.213843+00	2026-02-09 07:07:49.213843+00
11	6	msg_failed_1	+62818223304	+6281213775718	text	Test failed message	\N	\N	failed	f	2026-02-09 07:07:49.213843+00	2026-02-09 07:07:49.213843+00
12	6	3EB050960D0226C9AFD73D	+62818223304	+6281286431751	text	test	\N	\N	sent	f	2026-02-10 07:13:24.454524+00	2026-02-10 07:13:24.454524+00
13	6	3EB08B73B684F7F05CC1DD	+62818223304	6281286431751	text	Test message dengan mock fallback	\N	\N	sent	f	2026-02-10 07:46:49.648032+00	2026-02-10 07:46:49.648032+00
14	6	3EB0269F57DA467F58E6A0	+62818223304	+6287874875768	text	mu	\N	\N	sent	f	2026-02-10 08:00:05.589722+00	2026-02-10 08:00:05.589722+00
15	6	msg_1770729725944	+62812345678	+62818223304	text	halo	\N	\N	received	f	2026-02-10 13:22:05.944+00	2026-02-10 13:22:05.944909+00
16	6	msg_1770729737666	+62812345678	+62818223304	text	halo	\N	\N	received	f	2026-02-10 13:22:17.667+00	2026-02-10 13:22:17.666235+00
17	6	msg_1770729794147	+62812345678	+62818223304	text	halo	\N	\N	received	f	2026-02-10 13:23:14.147+00	2026-02-10 13:23:14.146195+00
18	6	msg_1770729818636	+62812345678	+62818223304	text	halo	\N	\N	received	f	2026-02-10 13:23:38.636+00	2026-02-10 13:23:38.636607+00
19	6	msg_1770729841311	+62812345678	+62818223304	text	halo	\N	\N	received	f	2026-02-10 13:24:01.311+00	2026-02-10 13:24:01.311698+00
20	6	msg_1770764848502	+62812345678	+62818223304	text	test message baru	\N	\N	received	f	2026-02-10 23:07:28.502+00	2026-02-10 23:07:28.503543+00
21	6	msg_go_whatsapp_123	+62812345678	+62818223304	chat	test message from go-whatsapp-web-multidevice	\N	\N	received	f	2026-02-10 23:09:21.755+00	2026-02-10 23:09:21.756496+00
22	6	msg_image_123	+62812345678	+62818223304	image		\N	\N	received	f	2026-02-10 23:09:33.435+00	2026-02-10 23:09:33.435729+00
23	6	msg_group_123	123456789	+62818223304	chat	group message test	\N	\N	received	f	2026-02-10 23:09:40.471+00	2026-02-10 23:09:40.472208+00
24	6	msg_autoreply_test	+62812345678	+62818223304	chat	halo	\N	\N	received	f	2026-02-10 23:10:00.137+00	2026-02-10 23:10:00.137697+00
\.


--
-- Data for Name: phone_numbers; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.phone_numbers (id, user_id, phone_number, device_name, token, webhook_url, webhook_secret, is_connected, last_seen, qr_code, session_data, auto_reply, auto_mark_read, auto_download_media, created_at, updated_at, evolution_instance) FROM stdin;
7	1	+62812345678	test-phone	test-token-12345	\N	\N	f	\N	\N	\N	\N	f	t	2026-02-10 12:58:56.430637+00	2026-02-10 12:58:56.430637+00	\N
6	1	+62818223304	mynumber	token_4b1c890895ab4858a56183822dafbbe5	http://localhost:8090/webhook/evolution	313313	t	\N	\N	\N	\N	f	t	2026-02-09 05:36:38.694606+00	2026-02-10 23:09:53.499074+00	chatflow-api-1:3000
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.rate_limits (id, user_id, window_start, request_count, limit_per_hour, created_at) FROM stdin;
\.


--
-- Data for Name: scheduled_messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.scheduled_messages (id, user_id, phone_id, recipient, message, scheduled_at, status, sent_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.users (id, username, email, password_hash, api_key, jwt_secret, is_active, created_at, updated_at) FROM stdin;
2	testuser	test@example.com	Admin123	test-api-key	test-jwt-secret	t	2026-02-08 15:31:26.131189+00	2026-02-08 15:31:26.131189+00
1	admin	admin@example.com	$2a$12$d87mP4MWIwmRBrzAHKnw0uIsOzIX07L74ixrvbOKWq4Yk/mYKdXSC	MySecureEvolutionKey2024!	random_jwt_secret_string_123	t	2026-02-08 15:12:25.028631+00	2026-02-08 15:31:53.092781+00
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.webhook_events (id, phone_number_id, event_type, payload, retry_count, status, sent_at, created_at) FROM stdin;
\.


--
-- Name: api_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.api_usage_id_seq', 1, false);


--
-- Name: auto_reply_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_configs_id_seq', 2, true);


--
-- Name: auto_reply_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_logs_id_seq', 1, true);


--
-- Name: auto_reply_menus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_menus_id_seq', 7, true);


--
-- Name: auto_reply_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_sessions_id_seq', 1, true);


--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_messages_id_seq', 1, false);


--
-- Name: broadcast_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_progress_id_seq', 1, false);


--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_recipients_id_seq', 31, true);


--
-- Name: broadcast_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_templates_id_seq', 1, true);


--
-- Name: broadcasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcasts_id_seq', 32, true);


--
-- Name: contact_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.contact_categories_id_seq', 6, true);


--
-- Name: contact_category_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.contact_category_relations_id_seq', 16, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.contacts_id_seq', 28, true);


--
-- Name: message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.message_templates_id_seq', 3, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 24, true);


--
-- Name: phone_numbers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.phone_numbers_id_seq', 7, true);


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 1, false);


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.scheduled_messages_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: webhook_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.webhook_events_id_seq', 1, false);


--
-- Name: api_usage api_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage
    ADD CONSTRAINT api_usage_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_configs auto_reply_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_configs
    ADD CONSTRAINT auto_reply_configs_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_logs auto_reply_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_logs
    ADD CONSTRAINT auto_reply_logs_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_menus auto_reply_menus_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus
    ADD CONSTRAINT auto_reply_menus_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_sessions auto_reply_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_pkey PRIMARY KEY (id);


--
-- Name: broadcast_messages broadcast_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_pkey PRIMARY KEY (id);


--
-- Name: broadcast_progress broadcast_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_progress
    ADD CONSTRAINT broadcast_progress_pkey PRIMARY KEY (id);


--
-- Name: broadcast_recipients broadcast_recipients_broadcast_id_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_broadcast_id_contact_id_key UNIQUE (broadcast_id, contact_id);


--
-- Name: broadcast_recipients broadcast_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_pkey PRIMARY KEY (id);


--
-- Name: broadcast_templates broadcast_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_templates
    ADD CONSTRAINT broadcast_templates_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_pkey PRIMARY KEY (id);


--
-- Name: contact_categories contact_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories
    ADD CONSTRAINT contact_categories_pkey PRIMARY KEY (id);


--
-- Name: contact_categories contact_categories_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories
    ADD CONSTRAINT contact_categories_user_id_name_key UNIQUE (user_id, name);


--
-- Name: contact_category_relations contact_category_relations_contact_id_category_id_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_contact_id_category_id_key UNIQUE (contact_id, category_id);


--
-- Name: contact_category_relations contact_category_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_user_id_phone_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_phone_key UNIQUE (user_id, phone);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: phone_numbers phone_numbers_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_pkey PRIMARY KEY (id);


--
-- Name: phone_numbers phone_numbers_token_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_token_key UNIQUE (token);


--
-- Name: phone_numbers phone_numbers_user_id_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_user_id_phone_number_key UNIQUE (user_id, phone_number);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_user_id_window_start_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_user_id_window_start_key UNIQUE (user_id, window_start);


--
-- Name: scheduled_messages scheduled_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_pkey PRIMARY KEY (id);


--
-- Name: users users_api_key_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_api_key_key UNIQUE (api_key);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: idx_api_usage_created_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_api_usage_created_at ON public.api_usage USING btree (created_at);


--
-- Name: idx_api_usage_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_api_usage_user_id ON public.api_usage USING btree (user_id);


--
-- Name: idx_auto_reply_configs_active; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_configs_active ON public.auto_reply_configs USING btree (is_active);


--
-- Name: idx_auto_reply_configs_phone_numbers; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_configs_phone_numbers ON public.auto_reply_configs USING gin (phone_numbers);


--
-- Name: idx_auto_reply_configs_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_configs_user_id ON public.auto_reply_configs USING btree (user_id);


--
-- Name: idx_auto_reply_logs_created; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_logs_created ON public.auto_reply_logs USING btree (created_at);


--
-- Name: idx_auto_reply_logs_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_logs_phone ON public.auto_reply_logs USING btree (phone_number);


--
-- Name: idx_auto_reply_menus_config_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_menus_config_id ON public.auto_reply_menus USING btree (config_id);


--
-- Name: idx_auto_reply_menus_parent_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_menus_parent_id ON public.auto_reply_menus USING btree (parent_menu_id);


--
-- Name: idx_auto_reply_sessions_active; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_sessions_active ON public.auto_reply_sessions USING btree (is_active);


--
-- Name: idx_auto_reply_sessions_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_sessions_phone ON public.auto_reply_sessions USING btree (phone_number);


--
-- Name: idx_auto_reply_sessions_phone_number_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_sessions_phone_number_id ON public.auto_reply_sessions USING btree (phone_number_id);


--
-- Name: idx_broadcast_messages_broadcast_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_messages_broadcast_id ON public.broadcast_messages USING btree (broadcast_id);


--
-- Name: idx_broadcast_messages_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_messages_status ON public.broadcast_messages USING btree (status);


--
-- Name: idx_broadcast_progress_broadcast_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_progress_broadcast_id ON public.broadcast_progress USING btree (broadcast_id);


--
-- Name: idx_broadcast_templates_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_templates_user_id ON public.broadcast_templates USING btree (user_id);


--
-- Name: idx_broadcasts_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcasts_status ON public.broadcasts USING btree (status);


--
-- Name: idx_broadcasts_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcasts_user_id ON public.broadcasts USING btree (user_id);


--
-- Name: idx_contact_categories_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contact_categories_user_id ON public.contact_categories USING btree (user_id);


--
-- Name: idx_contact_relations_category_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contact_relations_category_id ON public.contact_category_relations USING btree (category_id);


--
-- Name: idx_contact_relations_contact_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contact_relations_contact_id ON public.contact_category_relations USING btree (contact_id);


--
-- Name: idx_contacts_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contacts_phone ON public.contacts USING btree (phone);


--
-- Name: idx_contacts_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contacts_user_id ON public.contacts USING btree (user_id);


--
-- Name: idx_messages_created_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_messages_created_at ON public.messages USING btree (created_at);


--
-- Name: idx_messages_phone_number_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_messages_phone_number_id ON public.messages USING btree (phone_number_id);


--
-- Name: idx_messages_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_messages_status ON public.messages USING btree (status);


--
-- Name: idx_phone_numbers_token; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_phone_numbers_token ON public.phone_numbers USING btree (token);


--
-- Name: idx_phone_numbers_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_phone_numbers_user_id ON public.phone_numbers USING btree (user_id);


--
-- Name: idx_rate_limits_user_window; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_rate_limits_user_window ON public.rate_limits USING btree (user_id, window_start);


--
-- Name: idx_scheduled_messages_scheduled_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_scheduled_messages_scheduled_at ON public.scheduled_messages USING btree (scheduled_at);


--
-- Name: idx_scheduled_messages_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_scheduled_messages_status ON public.scheduled_messages USING btree (status);


--
-- Name: idx_users_api_key; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_users_api_key ON public.users USING btree (api_key);


--
-- Name: idx_webhook_events_phone_number_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_webhook_events_phone_number_id ON public.webhook_events USING btree (phone_number_id);


--
-- Name: idx_webhook_events_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_webhook_events_status ON public.webhook_events USING btree (status);


--
-- Name: auto_reply_configs update_auto_reply_configs_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_auto_reply_configs_updated_at BEFORE UPDATE ON public.auto_reply_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: messages update_messages_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_messages_updated_at BEFORE UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: phone_numbers update_phone_numbers_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_phone_numbers_updated_at BEFORE UPDATE ON public.phone_numbers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: api_usage api_usage_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage
    ADD CONSTRAINT api_usage_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id) ON DELETE CASCADE;


--
-- Name: api_usage api_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage
    ADD CONSTRAINT api_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auto_reply_configs auto_reply_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_configs
    ADD CONSTRAINT auto_reply_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auto_reply_logs auto_reply_logs_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_logs
    ADD CONSTRAINT auto_reply_logs_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auto_reply_sessions(id);


--
-- Name: auto_reply_menus auto_reply_menus_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus
    ADD CONSTRAINT auto_reply_menus_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.auto_reply_configs(id) ON DELETE CASCADE;


--
-- Name: auto_reply_menus auto_reply_menus_parent_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus
    ADD CONSTRAINT auto_reply_menus_parent_menu_id_fkey FOREIGN KEY (parent_menu_id) REFERENCES public.auto_reply_menus(id);


--
-- Name: auto_reply_sessions auto_reply_sessions_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.auto_reply_configs(id);


--
-- Name: auto_reply_sessions auto_reply_sessions_current_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_current_menu_id_fkey FOREIGN KEY (current_menu_id) REFERENCES public.auto_reply_menus(id);


--
-- Name: auto_reply_sessions auto_reply_sessions_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id);


--
-- Name: broadcast_messages broadcast_messages_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id);


--
-- Name: broadcast_messages broadcast_messages_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: broadcast_progress broadcast_progress_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_progress
    ADD CONSTRAINT broadcast_progress_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id);


--
-- Name: broadcast_recipients broadcast_recipients_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id) ON DELETE CASCADE;


--
-- Name: broadcast_recipients broadcast_recipients_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: broadcast_templates broadcast_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_templates
    ADD CONSTRAINT broadcast_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: broadcasts broadcasts_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.broadcast_templates(id);


--
-- Name: broadcasts broadcasts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: contact_categories contact_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories
    ADD CONSTRAINT contact_categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contact_category_relations contact_category_relations_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.contact_categories(id) ON DELETE CASCADE;


--
-- Name: contact_category_relations contact_category_relations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_templates message_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id) ON DELETE CASCADE;


--
-- Name: phone_numbers phone_numbers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rate_limits rate_limits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict L8xP09bmjsWwScrSdlGsdH1esHd7SgE8Z9ha06VOlSif9tavkoN26tbjQb9qIYb

